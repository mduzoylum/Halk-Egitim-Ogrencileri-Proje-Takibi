<?php
function baglan(){
	
//Sunucuya Bağlantı
$veritabani = "wordpress2";
$sunucu = "localhost";
$skadi = "root";
$sifre = "1234";
$baglanti = mysqli_connect($sunucu,$skadi,$sifre);

mysqli_select_db($baglanti,$veritabani);/*Veritabanına Bağlanma*/

return $baglanti;/*baglanti değişkenini döndürüyoruz*/
}

/*$s değişkenin sorgu olarak atama yapıyoruz, bunun nedeni kodları tekrar tekrar yazmak yerine gerekli olan kısımları tek bir değişkene atamak
 ve o değişkeni diğer sayfalarda çağırıyoruz */
function sorgu($s)
	{
		$baglan=baglan();
		mysqli_query($baglan,"SET NAMES 'utf8'");
		mysqli_query($baglan,"SET CHARACTER SET 'utf8_turkish_ci'");/*Veritabanımıza kayıt olan verileri utf8 olarak kaydediyoruz, bunun nedeni 
		türkçe karakterleri algılamamasıdır*/
		$deger=mysqli_query($baglan,$s);/*mysqli_query sorgumuzda kullanmak için $baglan değişkenimizi ve sorgu fonksiyonumuza 
		atadığımız $s değişkenimizi $deger değişkenine atıyoruz ve*/			
		return $deger;/*$deger değişkenimizi döndürüyoruz*/
	}
	
	function ks($a)
	{
		return mysqli_num_rows($a);/*ks'yi $a değişkenimize mysqli_num_rows sorgumuza atıyoruz*/
	}

?>

