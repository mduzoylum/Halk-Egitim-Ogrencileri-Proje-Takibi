<!doctype html>
<html>
<head>

<meta charset="utf-8">
<title>Veritabanı İle Kullanıcı Girişi</title>

</head>

<body>



</body>
</html>



<?php
session_start();
if(isset($_SESSION["ad"]))
{
echo "Hoşgeldiniz ".$_SESSION["ad"]."<br>";	
echo "Ana Sayfa"."<br>";
echo "Menüler"."<br>";
echo "İçerikler"."<br>";
echo "Galeri"."<br>";
echo "<a href=\"cikis.php\">Çıkış Yap</a>";
}
else
{
	echo "Üye girişi yapmalısınız...";
	header("refresh:2;url=giris.php");	
	
}
?>