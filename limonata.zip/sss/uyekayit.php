﻿<!doctype html>
<html>
<head>

<meta charset="utf-8">
<title>Kullanıcı Girişi</title>
<link href='https://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Arimo' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Hind:300' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300' rel='stylesheet' type='text/css'>

<link rel="stylesheet" href="css/stillkayit.css">

</head>

<body>
  <div id="login-button">
  <img src="devam.png">
  </img>
</div>


<div id="container">

<form method="post">
<table cellpadding="0" cellspacing="1" border="0">
 
  
	 <input type="text" name="kadi" placeholder="Kullanıcı Adı " required="required"> 	  
	 <input type="password" name="sifre" placeholder="Şifre " required="required"> 
	 <input type="text" name="ad" placeholder="Adı " required="required"> 
	 <input type="text" name="soyad" placeholder="Soyadı " required="required"> 
	 <input type="text" name="eposta" placeholder="E-Posta  " required="required"> 
	 <input type="submit" name="dugme" value="Kayıt Ol!"> 
 
</table>
</form>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/gsap/1.16.1/TweenMax.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>

<?php
require("config.php");

if(isset($_POST["dugme"]))
{
	$kadi=$_POST["kadi"];
	$sifre=$_POST["sifre"];
	$ad=$_POST["ad"];
	$soyad=$_POST["soyad"];
	$eposta=$_POST["eposta"];
	$baglan=baglan();
	$deger=mysqli_query($baglan,"INSERT into uyeler(kadi,sifre,ad,soyad,eposta)
									values('$kadi','$sifre','$ad','$soyad','$eposta')	
	");
	if($deger==true)
	{
		echo "Kayıt Başarılı";
		header("refresh:2;url=giris.php");	
	}
	else
	{
		echo "HATA...";		
	}
	
}


?>



